// script.js

// Function to create the color picker element
function createColorPicker() {
    // Create the color picker container
    var container = document.createElement('div');
    container.id = 'color-picker-container';
  
    // Create the color input element
    var colorInput = document.createElement('input');
    colorInput.type = 'color';
    colorInput.id = 'color-picker-input';
  
    // Append the color input to the container
    container.appendChild(colorInput);
  
    // Attach an event listener to the color input
    colorInput.addEventListener('change', function (event) {
      var color = event.target.value;
      // Do something with the selected color
      console.log('Selected color:', color);
    });
  
    // Append the container to the body
    document.body.appendChild(container);
  }
  
  // Invoke the createColorPicker function to initialize the color picker
  createColorPicker();
  